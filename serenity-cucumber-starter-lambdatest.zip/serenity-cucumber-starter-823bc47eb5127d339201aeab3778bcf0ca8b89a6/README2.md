please change the url in serenity.properties to your own personal lambdatest hub url


run the command -  mvn clean verify 